<?php
/**
 * Title: Startseite – Schmuck, Vorteile, Workshops, Bewertung, Rocket
 * Slug: ibr-theme/home-story
 * Categories: text
 * Viewport Width: 1280
 *
 * @package ibr-theme
 */

$ibr_schmuck = get_theme_file_uri( 'assets/images/schmuck.webp' );
$ibr_logo    = get_theme_file_uri( 'assets/images/logo-weiss.svg' );
?>
<!-- wp:group {"align":"full","className":"ibr-band","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"base","layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group alignfull ibr-band has-base-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:paragraph {"align":"center","className":"ibr-kicker ibr-kicker--hand"} -->
	<p class="has-text-align-center ibr-kicker ibr-kicker--hand">für dich</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center">Schmuck mit dem Namen deines Lieblings</h2>
	<!-- /wp:heading -->
	<!-- wp:html -->
	<figure class="ibr-polaroid"><img src="<?php echo esc_url( $ibr_schmuck ); ?>" alt="Goldene Kette mit Namensplättchen ELLA und Herz" width="480" height="853" loading="lazy"><figcaption>für Ella</figcaption></figure>
	<!-- /wp:html -->
	<!-- wp:paragraph {"align":"center"} -->
	<p class="has-text-align-center">Von Hand gestempelt, mit dem Namen deiner Wahl. Ein Geschenk, das bleibt.</p>
	<!-- /wp:paragraph -->
	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button -->
		<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/?product_cat=mensch' ) ); ?>">Jetzt gestalten</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<ul class="ibr-usps alignwide" aria-label="Was uns ausmacht">
	<li><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.6-7 10-7 10z"/></svg><span>Handmade<br>mit Liebe</span></li>
	<li><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z"/><path d="M9 12l2 2 4-4"/></svg><span>Geprüfte<br>Qualität</span></li>
	<li><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20l4-1 10-10-3-3L5 16l-1 4z"/></svg><span>Individuelle<br>Wünsche</span></li>
</ul>
<!-- /wp:html -->

<!-- wp:group {"anchor":"workshops","className":"ibr-section","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div id="workshops" class="wp-block-group ibr-section" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:paragraph {"className":"ibr-kicker ibr-kicker--hand"} -->
	<p class="ibr-kicker ibr-kicker--hand">selbermachen statt fertig kaufen</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading -->
	<h2 class="wp-block-heading">Workshops in Lingen &amp; Umgebung</h2>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Gestalte deine eigene Handykette oder Hundeleine. Wir zeigen dir jeden Knoten, du nimmst dein Lieblingsstück mit nach Hause.</p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph {"className":"ibr-note"} -->
	<p class="ibr-note">Die nächsten Termine mit Online-Buchung folgen in Kürze.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"ibr-section ibr-rating","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group ibr-section ibr-rating" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:html -->
	<p class="ibr-rating__score"><span class="ibr-rating__value">5,0</span> <span class="ibr-rating__stars" aria-label="5 von 5 Sternen">★★★★★</span></p>
	<p class="ibr-rating__label">Google-Bewertungen</p>
	<!-- /wp:html -->
	<!-- wp:paragraph {"align":"center","className":"ibr-kicker ibr-kicker--hand"} -->
	<p class="has-text-align-center ibr-kicker ibr-kicker--hand">eure Worte motivieren uns jeden Tag aufs Neue</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"ibr-rocket","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}},"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"backgroundColor":"primary","textColor":"base","layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group alignfull ibr-rocket has-base-color has-primary-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:html -->
	<img class="ibr-rocket__logo" src="<?php echo esc_url( $ibr_logo ); ?>" alt="" width="112" height="112" loading="lazy">
	<!-- /wp:html -->
	<!-- wp:paragraph {"className":"ibr-kicker ibr-kicker--hand ibr-kicker--light"} -->
	<p class="ibr-kicker ibr-kicker--hand ibr-kicker--light">Hallo, ich bin Rocket!</p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph {"className":"ibr-rocket__text"} -->
	<p class="ibr-rocket__text">Alles begann mit einer Leine für mich. Heute entstehen in Lingen Lieblingsstücke für Hunde und ihre Menschen, jedes einzelne von Hand.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
