<?php
/**
 * Title: Fußbereich
 * Slug: ibr-theme/footer
 * Categories: footer
 * Block Types: core/template-part/footer
 * Inserter: no
 *
 * @package ibr-theme
 */

$ibr_logo = get_theme_file_uri( 'assets/images/logo-weiss.svg' );
?>
<!-- wp:group {"tagName":"footer","align":"full","className":"ibr-footer","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|50"}},"elements":{"link":{"color":{"text":"var:preset|color|base"}}}},"backgroundColor":"primary-dark","textColor":"base","layout":{"type":"constrained"}} -->
<footer class="wp-block-group alignfull ibr-footer has-base-color has-primary-dark-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:columns {"align":"wide"} -->
	<div class="wp-block-columns alignwide">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<img class="ibr-footer__logo" src="<?php echo esc_url( $ibr_logo ); ?>" alt="Inspired by Rocket – handcrafted in Lingen, est. 2022" width="104" height="104">
			<!-- /wp:html -->
			<!-- wp:paragraph {"fontSize":"small"} -->
			<p class="has-small-font-size">Besondere Lieblingsstücke für Hund &amp; Mensch, von Hand gefertigt in Lingen (Ems).</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"className":"ibr-kicker ibr-kicker--light"} -->
			<p class="ibr-kicker ibr-kicker--light">Service</p>
			<!-- /wp:paragraph -->
			<!-- wp:list {"className":"ibr-footer__links","fontSize":"small"} -->
			<ul class="wp-block-list ibr-footer__links has-small-font-size">
				<!-- wp:list-item --><li><a href="<?php echo esc_url( home_url( '/faq/' ) ); ?>">FAQ</a></li><!-- /wp:list-item -->
				<!-- wp:list-item --><li><a href="<?php echo esc_url( home_url( '/versand/' ) ); ?>">Versand &amp; Zahlung</a></li><!-- /wp:list-item -->
				<!-- wp:list-item --><li><a href="<?php echo esc_url( home_url( '/kontakt/' ) ); ?>">Kontakt</a></li><!-- /wp:list-item -->
				<!-- wp:list-item --><li><a href="<?php echo esc_url( home_url( '/impressum/' ) ); ?>">Impressum</a></li><!-- /wp:list-item -->
				<!-- wp:list-item --><li><a href="<?php echo esc_url( home_url( '/datenschutz/' ) ); ?>">Datenschutz</a></li><!-- /wp:list-item -->
			</ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"className":"ibr-kicker ibr-kicker--light"} -->
			<p class="ibr-kicker ibr-kicker--light">Newsletter</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"small"} -->
			<p class="has-small-font-size">Neue Lieblingsstücke und Workshop-Termine zuerst erfahren. Die Anmeldung folgt in Kürze.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:paragraph {"align":"wide","fontSize":"x-small","className":"ibr-footer__copy"} -->
	<p class="alignwide ibr-footer__copy has-x-small-font-size">© <?php echo esc_html( gmdate( 'Y' ) ); ?> Inspired by Rocket · handcrafted in Lingen</p>
	<!-- /wp:paragraph -->
</footer>
<!-- /wp:group -->
