<?php
/**
 * Title: Kopfbereich
 * Slug: ibr-theme/header
 * Categories: header
 * Block Types: core/template-part/header
 * Inserter: no
 *
 * @package ibr-theme
 */

$ibr_logo = get_theme_file_uri( 'assets/images/logo-gruen.svg' );
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"0.55rem","bottom":"0.55rem"}}},"backgroundColor":"primary","textColor":"base","className":"ibr-announcement","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull ibr-announcement has-base-color has-primary-background-color has-text-color has-background" style="padding-top:0.55rem;padding-bottom:0.55rem">
	<!-- wp:paragraph {"align":"center","fontSize":"x-small"} -->
	<p class="has-text-align-center has-x-small-font-size">Handgemacht in Lingen · seit 2022</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"tagName":"header","align":"full","className":"ibr-header","style":{"spacing":{"padding":{"top":"0.5rem","bottom":"0.5rem"}},"border":{"bottom":{"color":"var:custom|line","width":"1px"}}},"backgroundColor":"surface","layout":{"type":"constrained"}} -->
<header class="wp-block-group alignfull ibr-header has-surface-background-color has-background" style="border-bottom-color:var(--wp--custom--line);border-bottom-width:1px;padding-top:0.5rem;padding-bottom:0.5rem">
	<!-- wp:group {"align":"wide","className":"ibr-header__row","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
	<div class="wp-block-group alignwide ibr-header__row">
		<!-- wp:navigation {"overlayMenu":"always","overlayBackgroundColor":"surface","overlayTextColor":"primary-dark","className":"ibr-header__nav","layout":{"type":"flex","orientation":"vertical"}} -->
			<!-- wp:navigation-link {"label":"Shop","url":"<?php echo esc_url( home_url( '/shop/' ) ); ?>","kind":"custom"} /-->
			<!-- wp:navigation-link {"label":"Für deinen Hund","url":"<?php echo esc_url( home_url( '/?product_cat=hund' ) ); ?>","kind":"custom"} /-->
			<!-- wp:navigation-link {"label":"Für dich","url":"<?php echo esc_url( home_url( '/?product_cat=mensch' ) ); ?>","kind":"custom"} /-->
			<!-- wp:navigation-link {"label":"Workshops","url":"<?php echo esc_url( home_url( '/#workshops' ) ); ?>","kind":"custom"} /-->
		<!-- /wp:navigation -->

		<!-- wp:html -->
		<a class="ibr-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Inspired by Rocket, zur Startseite">
			<img class="ibr-brand__logo" src="<?php echo esc_url( $ibr_logo ); ?>" alt="" width="52" height="52">
			<span class="ibr-brand__name">Inspired by Rocket</span>
		</a>
		<!-- /wp:html -->

		<!-- wp:group {"className":"ibr-header__actions","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"right"}} -->
		<div class="wp-block-group ibr-header__actions">
			<!-- wp:woocommerce/customer-account {"displayStyle":"icon_only","iconClass":"wc-block-customer-account__account-icon"} /-->
			<!-- wp:woocommerce/mini-cart /-->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->
</header>
<!-- /wp:group -->
