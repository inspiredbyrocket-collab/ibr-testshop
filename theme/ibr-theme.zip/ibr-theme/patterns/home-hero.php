<?php
/**
 * Title: Startseite – Titelbild
 * Slug: ibr-theme/home-hero
 * Categories: banner
 * Viewport Width: 1280
 *
 * @package ibr-theme
 */

$ibr_hero = get_theme_file_uri( 'assets/images/hero.webp' );
?>
<!-- wp:cover {"url":"<?php echo esc_url( $ibr_hero ); ?>","dimRatio":100,"customGradient":"linear-gradient(180deg,rgba(47,61,53,0) 35%,rgba(47,61,53,0.88) 100%)","focalPoint":{"x":0.5,"y":0.3},"minHeight":560,"contentPosition":"bottom left","isDark":true,"align":"full","className":"ibr-hero"} -->
<div class="wp-block-cover alignfull is-dark has-custom-content-position is-position-bottom-left ibr-hero" style="min-height:560px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-100 has-background-dim has-background-gradient" style="background:linear-gradient(180deg,rgba(47,61,53,0) 35%,rgba(47,61,53,0.88) 100%)"></span><img class="wp-block-cover__image-background" alt="Sandfarbene Seilleine mit Messingringen an einer Holzleiter" src="<?php echo esc_url( $ibr_hero ); ?>" style="object-position:50% 30%" data-object-fit="cover" data-object-position="50% 30%"/><div class="wp-block-cover__inner-container">
	<!-- wp:paragraph {"className":"ibr-sticker"} -->
	<p class="ibr-sticker">hand-<br>gemacht!</p>
	<!-- /wp:paragraph -->

	<!-- wp:group {"layout":{"type":"constrained","contentSize":"640px","justifyContent":"left"}} -->
	<div class="wp-block-group">
		<!-- wp:paragraph {"className":"ibr-kicker ibr-kicker--hand ibr-kicker--light"} -->
		<p class="ibr-kicker ibr-kicker--hand ibr-kicker--light">mit ganz viel Herz gemacht</p>
		<!-- /wp:paragraph -->

		<!-- wp:heading {"level":1,"textColor":"base"} -->
		<h1 class="wp-block-heading has-base-color has-text-color">Besondere Lieblingsstücke für Hund &amp; Mensch</h1>
		<!-- /wp:heading -->

		<!-- wp:buttons -->
		<div class="wp-block-buttons">
			<!-- wp:button {"backgroundColor":"base","textColor":"primary"} -->
			<div class="wp-block-button"><a class="wp-block-button__link has-primary-color has-base-background-color has-text-color has-background wp-element-button" href="<?php echo esc_url( home_url( '/shop/' ) ); ?>">Jetzt entdecken</a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
	<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->

<!-- wp:group {"align":"wide","className":"ibr-categories","style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}},"layout":{"type":"grid","columnCount":3,"minimumColumnWidth":null}} -->
<div class="wp-block-group alignwide ibr-categories" style="padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30)">
	<!-- wp:html -->
	<a class="ibr-pill ibr-pill--solid" href="<?php echo esc_url( home_url( '/?product_cat=hund' ) ); ?>">Hund</a>
	<!-- /wp:html -->
	<!-- wp:html -->
	<a class="ibr-pill" href="<?php echo esc_url( home_url( '/?product_cat=mensch' ) ); ?>">Mensch</a>
	<!-- /wp:html -->
	<!-- wp:html -->
	<a class="ibr-pill" href="#workshops">Workshops</a>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
