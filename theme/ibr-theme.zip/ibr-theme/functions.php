<?php
/**
 * Inspired by Rocket – Theme-Funktionen.
 *
 * Gestaltung steckt in theme.json; hier nur, was theme.json nicht abdeckt.
 *
 * @package ibr-theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Theme-Unterstützung, inklusive WooCommerce-Produktgalerie.
 */
function ibr_theme_setup(): void {
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	add_editor_style( 'assets/css/theme.css' );
}
add_action( 'after_setup_theme', 'ibr_theme_setup' );

/**
 * Kleine Ergänzungen zu theme.json (Fokus-Stile, Bewegungsreduktion).
 */
function ibr_theme_enqueue_styles(): void {
	$path = get_theme_file_path( 'assets/css/theme.css' );

	wp_enqueue_style(
		'ibr-theme',
		get_theme_file_uri( 'assets/css/theme.css' ),
		array(),
		file_exists( $path ) ? (string) filemtime( $path ) : wp_get_theme()->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'ibr_theme_enqueue_styles' );

/**
 * Die lokalen Hauptschriften früh laden, damit der Text nicht springt.
 */
function ibr_theme_preload_font(): void {
	foreach ( array( 'dosis/dosis-variable-latin.woff2', 'cormorant/cormorant-variable-latin.woff2' ) as $font ) {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( get_theme_file_uri( 'assets/fonts/' . $font ) )
		);
	}
}
add_action( 'wp_head', 'ibr_theme_preload_font', 1 );
