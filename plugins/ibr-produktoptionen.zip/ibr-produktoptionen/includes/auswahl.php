<?php
/**
 * Auswahl auf der Produktseite: Karten, Felder und Schalter statt Dropdown-Listen.
 *
 * Die WooCommerce-Auswahllisten bleiben im Hintergrund erhalten (unsichtbar), damit Preise,
 * Bestand und Warenkorb unverändert funktionieren. Darüber liegen Knöpfe:
 *  - Karten für die Eigenschaft, von der Farben/Aufpreis abhängen (z. B. Stärke),
 *    mit kurzer Erklärung (Produkt → Farbwahl → „Erklärungen zur Auswahl“) und „ab … €“
 *  - Schalter für Ja/Nein-Eigenschaften (ein Wert beginnt mit „Kein“, „Ohne“ oder „Nein“)
 *  - Felder für alles andere, bei Metallen mit kleinem Farbpunkt
 *
 * @package ibr-produktoptionen
 */

defined( 'ABSPATH' ) || exit;

/**
 * Erklärungen zu Auswahlwerten eines Produkts: „8 mm: leicht & fein“ je Zeile.
 *
 * @return array<string,string> Wert → Erklärung
 */
function ibr_auswahl_descriptions( int $product_id ): array {
	$out = array();
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_ibr_opt_desc', true ) ) as $line ) {
		if ( false !== strpos( $line, ':' ) ) {
			list( $value, $text ) = array_map( 'trim', explode( ':', $line, 2 ) );
			if ( '' !== $value && '' !== $text ) {
				$out[ $value ] = $text;
			}
		}
	}
	return $out;
}

/**
 * Kleiner Farbpunkt für Metalle und Grundfarben, sonst leer.
 */
function ibr_auswahl_dot( string $value ): string {
	$v = strtolower( $value );
	$map = array(
		'roségold'  => 'linear-gradient(135deg,#F1C6B5,#B77A68)',
		'rosegold'  => 'linear-gradient(135deg,#F1C6B5,#B77A68)',
		'messing'   => 'linear-gradient(135deg,#E6C77A,#A8823A)',
		'gold'      => 'linear-gradient(135deg,#F0D27A,#B8902F)',
		'edelstahl' => 'linear-gradient(135deg,#F2F2F2,#9EA3A6)',
		'silber'    => 'linear-gradient(135deg,#F7F7F7,#A9AEB1)',
		'schwarz'   => '#222222',
	);
	foreach ( $map as $needle => $background ) {
		if ( false !== strpos( $v, $needle ) ) {
			return $background;
		}
	}
	return '';
}

// Eigene Schrift- und Knopfgestaltung laden.
add_action(
	'wp_enqueue_scripts',
	static function (): void {
		if ( ! is_product() ) {
			return;
		}
		wp_enqueue_style( 'ibr-auswahl', plugins_url( 'assets/auswahl.css', IBR_PO_FILE ), array(), IBR_PO_VERSION );
		wp_enqueue_script( 'ibr-auswahl', plugins_url( 'assets/auswahl.js', IBR_PO_FILE ), array( 'jquery', 'wc-add-to-cart-variation' ), IBR_PO_VERSION, true );
	}
);

// Eigener Reiter „Auswahl-Texte“ für die Erklärungen auf den Karten.
add_filter(
	'woocommerce_product_data_tabs',
	static function ( array $tabs ): array {
		$tabs['ibr_auswahl'] = array(
			'label'    => 'Auswahl-Texte',
			'target'   => 'ibr_auswahl_panel',
			'class'    => array( 'show_if_variable' ),
			'priority' => 67,
		);
		return $tabs;
	}
);
add_action(
	'woocommerce_product_data_panels',
	static function (): void {
		echo '<div id="ibr_auswahl_panel" class="panel woocommerce_options_panel"><div class="options_group">';
		woocommerce_wp_textarea_input(
			array(
				'id'          => '_ibr_opt_desc',
				'label'       => 'Erklärungen zur Auswahl',
				'placeholder' => "8 mm: leicht & fein\n10 mm: kräftig & griffig",
				'desc_tip'    => true,
				'description' => 'Eine Zeile pro Wert, „Wert: Erklärung“. Erscheint auf den Karten der Produktseite (z. B. bei der Stärke).',
				'rows'        => 4,
			)
		);
		echo '</div></div>';
	}
);
add_action(
	'woocommerce_admin_process_product_object',
	static function ( WC_Product $product ): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$product->update_meta_data( '_ibr_opt_desc', sanitize_textarea_field( wp_unslash( $_POST['_ibr_opt_desc'] ?? '' ) ) );
	}
);

/**
 * Preise je Wert für die Anzeige „ab … €“ und „+ … €“.
 * Ergebnis: [ Hauptwert => [ Eigenschaft => [ Wert => kleinster Preis ] ] ] und kleinster Preis je Hauptwert.
 */
function ibr_auswahl_price_data( WC_Product $product, string $main_attr ): array {
	$prices = array();
	$from   = array();
	foreach ( $product->get_available_variations( 'objects' ) as $variation ) {
		if ( ! $variation->is_purchasable() ) {
			continue;
		}
		$attrs = $variation->get_variation_attributes();
		$main  = (string) ( $attrs[ $main_attr ] ?? '' );
		$price = (float) wc_get_price_to_display( $variation );
		$from[ $main ] = isset( $from[ $main ] ) ? min( $from[ $main ], $price ) : $price;
		foreach ( $attrs as $attr => $value ) {
			if ( $attr === $main_attr ) {
				continue;
			}
			$current                             = $prices[ $main ][ $attr ][ $value ] ?? null;
			$prices[ $main ][ $attr ][ $value ] = null === $current ? $price : min( $current, $price );
		}
	}
	return array( 'by_main' => $prices, 'from' => $from );
}

// Knöpfe unter jede Auswahlliste setzen.
add_filter(
	'woocommerce_dropdown_variation_attribute_options_html',
	static function ( string $html, array $args ): string {
		$product = $args['product'] ?? null;
		if ( ! $product instanceof WC_Product_Variable || empty( $args['options'] ) ) {
			return $html;
		}
		$attr_name = 'attribute_' . sanitize_title( $args['attribute'] );
		$options   = array_values( $args['options'] );

		// Hauptauswahl: bestimmt Farben bzw. Aufpreis; sonst die erste Eigenschaft.
		static $main_cache = array();
		$pid = $product->get_id();
		if ( ! isset( $main_cache[ $pid ] ) ) {
			$main = null;
			if ( function_exists( 'ibr_fw_settings' ) && ( $fw = ibr_fw_settings( $pid ) ) ) {
				$main = ibr_po_attribute_map( $product, static fn( int $v ) => ibr_fw_palette_for( $v, $fw ) )['attr'] ?? null;
			}
			if ( ! $main ) {
				$keys = array_keys( $product->get_variation_attributes() );
				$main = 'attribute_' . sanitize_title( $keys[0] ?? '' );
			}
			$main_cache[ $pid ] = $main;
		}
		$main_attr = $main_cache[ $pid ];
		$data      = ibr_auswahl_price_data( $product, $main_attr );

		$is_main = $attr_name === $main_attr;
		$off     = null;
		foreach ( $options as $option ) {
			if ( preg_match( '/^(kein|keine|ohne|nein)\b/iu', $option ) ) {
				$off = $option;
			}
		}
		$is_switch = ! $is_main && 2 === count( $options ) && null !== $off;

		$out = '<div class="ibr-sel" data-attr="' . esc_attr( $attr_name ) . '"' . ( $is_main ? ' data-main="1"' : '' ) . '>';

		if ( $is_switch ) {
			$on = $options[0] === $off ? $options[1] : $options[0];
			$out .= sprintf(
				'<button type="button" class="ibr-sel__switch" role="switch" aria-checked="false" data-on="%1$s" data-off="%2$s"><span class="ibr-sel__switch-text"><strong>%3$s</strong><span>%4$s <span class="ibr-sel__diff" data-value="%1$s"></span></span></span><span class="ibr-sel__toggle" aria-hidden="true"></span></button>',
				esc_attr( $on ),
				esc_attr( $off ),
				esc_html( wc_attribute_label( $args['attribute'], $product ) ),
				esc_html( $on )
			);
		} elseif ( $is_main ) {
			$descriptions = ibr_auswahl_descriptions( $pid );
			$out         .= '<div class="ibr-sel__cards">';
			foreach ( $options as $option ) {
				$from = $data['from'][ $option ] ?? null;
				$out .= sprintf(
					'<button type="button" class="ibr-sel__card" data-value="%1$s" aria-pressed="false"><span class="ibr-sel__card-title">%2$s</span>%3$s%4$s</button>',
					esc_attr( $option ),
					esc_html( $option ),
					isset( $descriptions[ $option ] ) ? '<span class="ibr-sel__card-text">' . esc_html( $descriptions[ $option ] ) . '</span>' : '',
					null !== $from ? '<span class="ibr-sel__card-price">ab ' . wp_kses_post( wc_price( $from ) ) . '</span>' : ''
				);
			}
			$out .= '</div>';
		} else {
			$out .= '<div class="ibr-sel__fields">';
			foreach ( $options as $option ) {
				$dot  = ibr_auswahl_dot( $option );
				$out .= sprintf(
					'<button type="button" class="ibr-sel__field" data-value="%1$s" aria-pressed="false">%2$s<span>%3$s</span> <span class="ibr-sel__diff" data-value="%1$s"></span></button>',
					esc_attr( $option ),
					$dot ? '<span class="ibr-sel__dot" style="background:' . esc_attr( $dot ) . '"></span>' : '',
					esc_html( $option )
				);
			}
			$out .= '</div>';
		}
		$out .= '</div>';

		// Preisdaten einmal pro Produkt für die Aufpreis-Anzeige mitgeben.
		static $printed = array();
		if ( empty( $printed[ $pid ] ) ) {
			$printed[ $pid ] = true;
			$out            .= sprintf(
				'<script type="application/json" class="ibr-sel-data">%s</script>',
				wp_json_encode(
					array(
						'main'   => $main_attr,
						'prices' => $data['by_main'],
						'format' => array(
							'decimals'  => wc_get_price_decimals(),
							'decimal'   => wc_get_price_decimal_separator(),
							'thousand'  => wc_get_price_thousand_separator(),
							'symbol'    => html_entity_decode( get_woocommerce_currency_symbol() ),
						),
					)
				)
			);
		}

		return '<div class="ibr-sel-native">' . $html . '</div>' . $out;
	},
	10,
	2
);
