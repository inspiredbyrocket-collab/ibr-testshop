<?php
/**
 * Farbwahl: Seilfarben mit Foto als Auswahl am Produkt.
 *
 * @package ibr-produktoptionen
 */

defined( 'ABSPATH' ) || exit;

const IBR_FW_CPT     = 'ibr_farbe';
const IBR_FW_TAX     = 'ibr_palette';

/* ---------------------------------------------------------------------------
 * Seilfarben (eigener Beitragstyp) und Paletten (Taxonomie)
 * ------------------------------------------------------------------------- */

add_action(
	'init',
	static function (): void {
		register_post_type(
			IBR_FW_CPT,
			array(
				'labels'        => array(
					'name'               => 'Seilfarben',
					'singular_name'      => 'Seilfarbe',
					'add_new'            => 'Farbe hinzufügen',
					'add_new_item'       => 'Neue Seilfarbe',
					'edit_item'          => 'Seilfarbe bearbeiten',
					'search_items'       => 'Seilfarben suchen',
					'not_found'          => 'Noch keine Seilfarben angelegt.',
					'featured_image'     => 'Foto vom Seil',
					'set_featured_image' => 'Foto vom Seil festlegen',
				),
				'public'        => false,
				'show_ui'       => true,
				'show_in_menu'  => 'edit.php?post_type=product',
				'show_in_rest'  => true,
				'supports'      => array( 'title', 'thumbnail', 'page-attributes' ),
				'menu_icon'     => 'dashicons-art',
				'hierarchical'  => false,
			)
		);

		register_taxonomy(
			IBR_FW_TAX,
			IBR_FW_CPT,
			array(
				'labels'            => array(
					'name'          => 'Farbpaletten',
					'singular_name' => 'Farbpalette',
					'add_new_item'  => 'Neue Farbpalette',
					'edit_item'     => 'Farbpalette bearbeiten',
				),
				'public'            => false,
				'show_ui'           => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'hierarchical'      => true,
			)
		);

		register_post_meta(
			IBR_FW_CPT,
			'_ibr_fw_hex',
			array(
				'type'          => 'string',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => static fn() => current_user_can( 'edit_products' ),
			)
		);
	}
);

/**
 * Farbfeld (Ersatz, solange kein Foto da ist) in der Seitenleiste der Seilfarbe.
 */
add_action(
	'add_meta_boxes_' . IBR_FW_CPT,
	static function (): void {
		add_meta_box(
			'ibr_fw_hex',
			'Ersatzfarbe',
			static function ( WP_Post $post ): void {
				wp_nonce_field( 'ibr_fw_hex', 'ibr_fw_hex_nonce' );
				printf(
					'<p><label for="ibr_fw_hex_field">Wird gezeigt, solange kein Foto vom Seil hinterlegt ist.</label></p><input type="color" id="ibr_fw_hex_field" name="ibr_fw_hex" value="%s">',
					esc_attr( get_post_meta( $post->ID, '_ibr_fw_hex', true ) ?: '#c8b79a' )
				);
			},
			IBR_FW_CPT,
			'side'
		);
	}
);

add_action(
	'save_post_' . IBR_FW_CPT,
	static function ( int $post_id ): void {
		if ( ! isset( $_POST['ibr_fw_hex_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['ibr_fw_hex_nonce'] ), 'ibr_fw_hex' ) ) {
			return;
		}
		$hex = sanitize_hex_color( wp_unslash( $_POST['ibr_fw_hex'] ?? '' ) );
		update_post_meta( $post_id, '_ibr_fw_hex', $hex ?: '' );
	}
);

/* ---------------------------------------------------------------------------
 * Einstellungen am Produkt (Reiter „Farbwahl“)
 * ------------------------------------------------------------------------- */

/**
 * Farbwahl-Einstellungen eines Produkts.
 *
 * @return array{palette:int,slots:int,slot_attr:string,labels:array<int,string>}|null
 */
function ibr_fw_settings( int $product_id ): ?array {
	$palette = (int) get_post_meta( $product_id, '_ibr_fw_palette', true );
	$by_var  = 'yes' === get_post_meta( $product_id, '_ibr_fw_by_variation', true );
	if ( ! $palette && ! $by_var ) {
		return null;
	}
	$labels = array_values( array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $product_id, '_ibr_fw_labels', true ) ) ) ) );
	return array(
		'palette'   => $palette,
		'slots'     => max( 1, (int) get_post_meta( $product_id, '_ibr_fw_slots', true ) ),
		'slot_attr' => (string) get_post_meta( $product_id, '_ibr_fw_slot_attr', true ),
		'labels'    => $labels,
	);
}

/**
 * Palette für die gewählte Variante: eigene Palette der Variante, sonst die des Produkts.
 */
function ibr_fw_palette_for( int $variation_id, array $settings ): int {
	if ( $variation_id ) {
		$own = (int) get_post_meta( $variation_id, '_ibr_fw_palette', true );
		if ( $own ) {
			return $own;
		}
	}
	return (int) $settings['palette'];
}

/**
 * Alle Paletten, die bei einem Produkt vorkommen können (Produkt und Varianten).
 *
 * @return int[]
 */
function ibr_fw_palettes( WC_Product $product, array $settings ): array {
	$ids = $settings['palette'] ? array( (int) $settings['palette'] ) : array();
	foreach ( $product->get_children() as $child ) {
		$own = (int) get_post_meta( $child, '_ibr_fw_palette', true );
		if ( $own ) {
			$ids[] = $own;
		}
	}
	return array_values( array_unique( $ids ) );
}

/**
 * Merkt am Produkt, ob einzelne Varianten eine eigene Palette haben (für schnelle Abfragen).
 */
function ibr_fw_refresh_variation_flag( int $product_id ): void {
	$product = wc_get_product( $product_id );
	$has     = false;
	foreach ( $product ? $product->get_children() : array() as $child ) {
		if ( get_post_meta( $child, '_ibr_fw_palette', true ) ) {
			$has = true;
			break;
		}
	}
	update_post_meta( $product_id, '_ibr_fw_by_variation', $has ? 'yes' : 'no' );
}

/**
 * Farben einer Palette in ihrer Reihenfolge.
 *
 * @return array<int,array{id:int,name:string,image:string,hex:string}>
 */
function ibr_fw_colors( int $palette ): array {
	$posts = get_posts(
		array(
			'post_type'   => IBR_FW_CPT,
			'numberposts' => 100,
			'orderby'     => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
			'tax_query'   => array(
				array(
					'taxonomy' => IBR_FW_TAX,
					'terms'    => $palette,
				),
			),
		)
	);
	return array_map(
		static fn( WP_Post $p ) => array(
			'id'    => $p->ID,
			'name'  => $p->post_title,
			'image' => (string) get_the_post_thumbnail_url( $p, 'thumbnail' ),
			'hex'   => (string) get_post_meta( $p->ID, '_ibr_fw_hex', true ),
		),
		$posts
	);
}

add_filter(
	'woocommerce_product_data_tabs',
	static function ( array $tabs ): array {
		$tabs['ibr_farbwahl'] = array(
			'label'    => 'Farbwahl',
			'target'   => 'ibr_farbwahl_panel',
			'priority' => 65,
		);
		return $tabs;
	}
);

add_action(
	'woocommerce_product_data_panels',
	static function (): void {
		global $post;
		$palettes = get_terms( array( 'taxonomy' => IBR_FW_TAX, 'hide_empty' => false ) );
		$options  = array( '' => '– keine Farbwahl –' );
		foreach ( is_array( $palettes ) ? $palettes : array() as $term ) {
			$options[ $term->term_id ] = $term->name;
		}
		echo '<div id="ibr_farbwahl_panel" class="panel woocommerce_options_panel"><div class="options_group">';
		woocommerce_wp_select(
			array(
				'id'          => '_ibr_fw_palette',
				'label'       => 'Farbpalette',
				'options'     => $options,
				'desc_tip'    => true,
				'description' => 'Aus welchen Seilfarben Kund*innen wählen können. Paletten und Farben pflegst du unter Produkte → Seilfarben.',
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'                => '_ibr_fw_slots',
				'label'             => 'Anzahl Farben',
				'type'              => 'number',
				'custom_attributes' => array( 'min' => 1, 'max' => 8 ),
				'placeholder'       => '1',
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'          => '_ibr_fw_labels',
				'label'       => 'Bezeichnungen',
				'placeholder' => 'z. B. Seilfarbe, Wicklung',
				'desc_tip'    => true,
				'description' => 'Durch Komma getrennt, eine pro Farbe. Leer lassen für „Farbe 1“, „Farbe 2“ …',
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'          => '_ibr_fw_slot_attr',
				'label'       => 'Anzahl aus Variante',
				'placeholder' => 'z. B. Anzahl Farben',
				'desc_tip'    => true,
				'description' => 'Optional: Name einer Varianten-Eigenschaft. Die erste Zahl im gewählten Wert bestimmt die Anzahl der Farben (z. B. „4 Farben“ → 4).',
			)
		);
		echo '</div></div>';
	}
);

add_action(
	'woocommerce_admin_process_product_object',
	static function ( WC_Product $product ): void {
		// Die Nonce prüft WooCommerce beim Speichern des Produkts.
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$product->update_meta_data( '_ibr_fw_palette', absint( $_POST['_ibr_fw_palette'] ?? 0 ) ?: '' );
		$product->update_meta_data( '_ibr_fw_slots', min( 8, max( 1, absint( $_POST['_ibr_fw_slots'] ?? 1 ) ) ) );
		$product->update_meta_data( '_ibr_fw_labels', sanitize_text_field( wp_unslash( $_POST['_ibr_fw_labels'] ?? '' ) ) );
		$product->update_meta_data( '_ibr_fw_slot_attr', sanitize_text_field( wp_unslash( $_POST['_ibr_fw_slot_attr'] ?? '' ) ) );
		// phpcs:enable
	}
);

/* ---------------------------------------------------------------------------
 * Auswahl auf der Produktseite
 * ------------------------------------------------------------------------- */

add_action(
	'wp_enqueue_scripts',
	static function (): void {
		if ( ! is_product() ) {
			return;
		}
		wp_enqueue_style( 'ibr-farbwahl', plugins_url( 'assets/farbwahl.css', IBR_PO_FILE ), array(), IBR_PO_VERSION );
		wp_enqueue_script( 'ibr-farbwahl', plugins_url( 'assets/farbwahl.js', IBR_PO_FILE ), array( 'jquery' ), IBR_PO_VERSION, true );
	}
);

add_action(
	'woocommerce_before_add_to_cart_button',
	static function (): void {
		global $product;
		if ( ! $product instanceof WC_Product ) {
			return;
		}
		$settings = ibr_fw_settings( $product->get_id() );
		if ( ! $settings ) {
			return;
		}
		$palettes = array();
		foreach ( ibr_fw_palettes( $product, $settings ) as $palette_id ) {
			$colors = ibr_fw_colors( $palette_id );
			if ( $colors ) {
				$palettes[ $palette_id ] = $colors;
			}
		}
		if ( ! $palettes ) {
			return;
		}
		$default = isset( $palettes[ (int) $settings['palette'] ] ) ? (int) $settings['palette'] : 0;
		$max     = $settings['slot_attr'] ? 8 : $settings['slots'];

		// Welche Eigenschaft bestimmt die Palette (z. B. Stärke)? Dann zeigen wir die Farben schon nach dieser Wahl.
		$by_attr = ibr_po_attribute_map(
			$product,
			static fn( int $variation_id ) => ibr_fw_palette_for( $variation_id, $settings )
		);

		printf(
			'<fieldset class="ibr-fw" data-slots="%d" data-slot-attr="%s" data-default-palette="%d" data-palette-attr="%s" data-palette-map="%s"><legend class="ibr-fw__title">Deine Farben</legend>',
			(int) $settings['slots'],
			esc_attr( sanitize_title( $settings['slot_attr'] ) ),
			(int) $default,
			esc_attr( $by_attr['attr'] ?? '' ),
			esc_attr( wp_json_encode( $by_attr['map'] ?? new stdClass() ) )
		);
		printf(
			'<p class="ibr-fw__wait"%s>Bitte wähle zuerst die Stärke bzw. Ausführung, dann zeigen wir dir die passenden Farben.</p>',
			$default ? ' hidden' : ''
		);
		for ( $i = 0; $i < $max; $i++ ) {
			$label       = $settings['labels'][ $i ] ?? sprintf( 'Farbe %d', $i + 1 );
			$slot_active = $i < $settings['slots'] && $default;
			printf(
				'<div class="ibr-fw__slot" data-slot="%1$d"%2$s><p class="ibr-fw__label">%3$s: <span class="ibr-fw__chosen" aria-live="polite">bitte wählen</span></p>',
				(int) $i,
				$slot_active ? '' : ' hidden',
				esc_html( $label )
			);
			foreach ( $palettes as $palette_id => $colors ) {
				$group_active = $slot_active && $palette_id === $default;
				printf(
					'<div class="ibr-fw__swatches" data-palette="%1$d" role="radiogroup" aria-label="%2$s"%3$s>',
					(int) $palette_id,
					esc_attr( $label ),
					$palette_id === $default ? '' : ' hidden'
				);
				foreach ( $colors as $color ) {
					$style = $color['image']
						? sprintf( 'background-image:url(%s)', esc_url( $color['image'] ) )
						: sprintf( '--ibr-fw-hex:%s', esc_attr( $color['hex'] ?: '#c8b79a' ) );
					printf(
						'<label class="ibr-fw__swatch%5$s" title="%3$s"><input type="radio" name="ibr_fw[%1$d]" value="%2$d"%6$s><span class="ibr-fw__chip" style="%4$s"></span><span class="screen-reader-text">%3$s</span></label>',
						(int) $i,
						(int) $color['id'],
						esc_attr( $color['name'] ),
						$style,
						$color['image'] ? ' has-image' : '',
						$group_active ? '' : ' disabled'
					);
				}
				echo '</div>';
			}
			echo '</div>';
		}
		echo '</fieldset>';
	}
);

/* ---------------------------------------------------------------------------
 * Warenkorb und Bestellung
 * ------------------------------------------------------------------------- */

/**
 * Anzahl der Farben für das konkrete Produkt bzw. die gewählte Variante.
 */
function ibr_fw_slot_count( int $product_id, int $variation_id, array $settings ): int {
	if ( ! $settings['slot_attr'] || ! $variation_id ) {
		return $settings['slots'];
	}
	$variation = wc_get_product( $variation_id );
	$value     = $variation ? (string) $variation->get_attribute( $settings['slot_attr'] ) : '';
	if ( preg_match( '/\d+/', $value, $m ) ) {
		return min( 8, max( 1, (int) $m[0] ) );
	}
	return $settings['slots'];
}

add_filter(
	'woocommerce_add_to_cart_validation',
	static function ( bool $valid, int $product_id, int $qty, int $variation_id = 0 ): bool {
		$settings = ibr_fw_settings( $product_id );
		if ( ! $settings ) {
			return $valid;
		}
		$chosen  = array_map( 'absint', (array) wp_unslash( $_POST['ibr_fw'] ?? array() ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$palette = ibr_fw_palette_for( $variation_id, $settings );
		if ( ! $palette ) {
			wc_add_notice( 'Bitte wähle zuerst die Ausführung.', 'error' );
			return false;
		}
		$allowed = wp_list_pluck( ibr_fw_colors( $palette ), 'id' );
		$count   = ibr_fw_slot_count( $product_id, $variation_id, $settings );
		for ( $i = 0; $i < $count; $i++ ) {
			if ( empty( $chosen[ $i ] ) || ! in_array( $chosen[ $i ], $allowed, true ) ) {
				$label = $settings['labels'][ $i ] ?? sprintf( 'Farbe %d', $i + 1 );
				wc_add_notice( sprintf( 'Bitte wähle noch: %s.', $label ), 'error' );
				return false;
			}
		}
		return $valid;
	},
	10,
	4
);

add_filter(
	'woocommerce_add_cart_item_data',
	static function ( array $data, int $product_id, int $variation_id ): array {
		$settings = ibr_fw_settings( $product_id );
		if ( ! $settings ) {
			return $data;
		}
		$chosen = array_map( 'absint', (array) wp_unslash( $_POST['ibr_fw'] ?? array() ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$count  = ibr_fw_slot_count( $product_id, $variation_id, $settings );
		$items  = array();
		for ( $i = 0; $i < $count; $i++ ) {
			if ( ! empty( $chosen[ $i ] ) ) {
				$items[] = array(
					'label' => $settings['labels'][ $i ] ?? sprintf( 'Farbe %d', $i + 1 ),
					'color' => get_the_title( $chosen[ $i ] ),
				);
			}
		}
		if ( $items ) {
			$data['ibr_fw'] = $items;
		}
		return $data;
	},
	10,
	3
);

add_filter(
	'woocommerce_get_item_data',
	static function ( array $item_data, array $cart_item ): array {
		foreach ( $cart_item['ibr_fw'] ?? array() as $entry ) {
			$item_data[] = array(
				'key'   => $entry['label'],
				'value' => $entry['color'],
			);
		}
		return $item_data;
	},
	10,
	2
);

add_action(
	'woocommerce_checkout_create_order_line_item',
	static function ( WC_Order_Item_Product $item, string $key, array $values ): void {
		foreach ( $values['ibr_fw'] ?? array() as $entry ) {
			$item->add_meta_data( $entry['label'], $entry['color'] );
		}
	},
	10,
	3
);

/* ---------------------------------------------------------------------------
 * Übersichten: Produkte mit Farbwahl führen zur Produktseite statt direkt in den Warenkorb
 * ------------------------------------------------------------------------- */

add_filter(
	'woocommerce_product_supports',
	static function ( bool $supports, string $feature, WC_Product $product ): bool {
		if ( 'ajax_add_to_cart' === $feature && ibr_fw_settings( $product->get_id() ) ) {
			return false;
		}
		return $supports;
	},
	10,
	3
);

add_filter(
	'woocommerce_product_add_to_cart_url',
	static function ( string $url, WC_Product $product ): string {
		return ( $product->is_type( 'simple' ) && ibr_fw_settings( $product->get_id() ) ) ? $product->get_permalink() : $url;
	},
	10,
	2
);

add_filter(
	'woocommerce_product_add_to_cart_text',
	static function ( string $text, WC_Product $product ): string {
		return ( $product->is_type( 'simple' ) && ibr_fw_settings( $product->get_id() ) ) ? 'Farben wählen' : $text;
	},
	10,
	2
);

/* ---------------------------------------------------------------------------
 * Eigene Palette pro Variante (z. B. andere Farben für 8 mm und 10 mm)
 * ------------------------------------------------------------------------- */

add_action(
	'woocommerce_product_after_variable_attributes',
	static function ( int $loop, array $variation_data, WP_Post $variation ): void {
		$palettes = get_terms( array( 'taxonomy' => IBR_FW_TAX, 'hide_empty' => false ) );
		$options  = array( '' => 'wie beim Produkt' );
		foreach ( is_array( $palettes ) ? $palettes : array() as $term ) {
			$options[ $term->term_id ] = $term->name;
		}
		woocommerce_wp_select(
			array(
				'id'            => "ibr_fw_palette_{$loop}",
				'name'          => "ibr_fw_palette[{$loop}]",
				'label'         => 'Farbpalette dieser Variante',
				'options'       => $options,
				'value'         => (string) get_post_meta( $variation->ID, '_ibr_fw_palette', true ),
				'wrapper_class' => 'form-row form-row-first',
			)
		);
	},
	10,
	3
);

add_action(
	'woocommerce_save_product_variation',
	static function ( int $variation_id, int $loop ): void {
		// Die Nonce prüft WooCommerce beim Speichern der Varianten.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$palette = absint( wp_unslash( $_POST['ibr_fw_palette'][ $loop ] ?? 0 ) );
		update_post_meta( $variation_id, '_ibr_fw_palette', $palette ?: '' );
		ibr_fw_refresh_variation_flag( (int) wp_get_post_parent_id( $variation_id ) );
	},
	10,
	2
);

// Palette der Variante an die Produktseite übergeben, damit die Farben beim Wechsel mitwechseln.
add_filter(
	'woocommerce_available_variation',
	static function ( array $data, WC_Product $product, WC_Product_Variation $variation ): array {
		$settings = ibr_fw_settings( $product->get_id() );
		if ( $settings ) {
			$data['ibr_fw_palette'] = ibr_fw_palette_for( $variation->get_id(), $settings );
		}
		return $data;
	},
	10,
	3
);
