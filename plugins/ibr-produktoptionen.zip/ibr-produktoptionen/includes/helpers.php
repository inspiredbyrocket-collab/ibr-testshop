<?php
/**
 * Gemeinsame Hilfsfunktionen der Produktoptionen.
 *
 * @package ibr-produktoptionen
 */

defined( 'ABSPATH' ) || exit;

/**
 * Findet die Varianten-Eigenschaft, von der ein Wert allein abhängt (z. B. Farbpalette ← Stärke),
 * damit die Produktseite ihn schon zeigen kann, bevor alle Eigenschaften gewählt sind.
 *
 * @param WC_Product $product Variables Produkt.
 * @param callable   $value   Liefert für eine Varianten-ID den Wert (z. B. Paletten-ID).
 * @return array{attr:string,map:array<string,mixed>}|null Formularfeld (z. B. attribute_staerke) und Zuordnung Wert → Ergebnis.
 */
function ibr_po_attribute_map( WC_Product $product, callable $value ): ?array {
	if ( ! $product->is_type( 'variable' ) ) {
		return null;
	}
	$rows = array();
	foreach ( $product->get_children() as $child ) {
		$variation = wc_get_product( $child );
		if ( $variation ) {
			$rows[] = array( $variation->get_variation_attributes(), $value( (int) $child ) );
		}
	}
	if ( ! $rows ) {
		return null;
	}
	foreach ( array_keys( $rows[0][0] ) as $attr ) {
		$map = array();
		$ok  = true;
		foreach ( $rows as list( $attributes, $result ) ) {
			$key = (string) ( $attributes[ $attr ] ?? '' );
			if ( '' === $key || ( isset( $map[ $key ] ) && $map[ $key ] !== $result ) ) {
				$ok = false; // „beliebig“ oder widersprüchlich: diese Eigenschaft bestimmt den Wert nicht allein
				break;
			}
			$map[ $key ] = $result;
		}
		if ( $ok && count( array_unique( array_map( 'serialize', $map ) ) ) > 1 ) {
			return array( 'attr' => $attr, 'map' => $map );
		}
	}
	return null;
}
