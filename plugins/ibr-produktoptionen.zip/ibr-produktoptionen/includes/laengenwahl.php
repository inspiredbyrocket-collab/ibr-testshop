<?php
/**
 * Längenwahl: Standardlänge, feste Zusatzlängen und Wunschlänge mit automatischem Aufpreis.
 *
 * Einstellungen pro Produkt (Reiter „Länge“):
 *   _ibr_len_standard   Standardlänge in cm (z. B. 200)
 *   _ibr_len_steps      weitere Längen in cm, durch Komma getrennt (z. B. 225, 250)
 *   _ibr_len_custom     'yes' = Wunschlänge erlaubt
 *   _ibr_len_min/_max   Grenzen für die Wunschlänge in cm
 *   _ibr_len_surcharge  Aufpreis in € je angefangene _ibr_len_step_cm über der Standardlänge
 *   _ibr_len_step_cm    Schrittweite für den Aufpreis in cm (Standard 25)
 *
 * @package ibr-produktoptionen
 */

defined( 'ABSPATH' ) || exit;

/**
 * Längen-Einstellungen eines Produkts, oder null wenn keine Längenwahl aktiv ist.
 *
 * @return array{standard:int,steps:int[],custom:bool,min:int,max:int,surcharge:float,step_cm:int}|null
 */
function ibr_len_settings( int $product_id ): ?array {
	$standard = (int) get_post_meta( $product_id, '_ibr_len_standard', true );
	if ( $standard <= 0 ) {
		return null;
	}
	$steps = array_values(
		array_unique(
			array_filter(
				array_map( 'intval', explode( ',', (string) get_post_meta( $product_id, '_ibr_len_steps', true ) ) ),
				static fn( int $cm ) => $cm > 0 && $cm !== $standard
			)
		)
	);
	sort( $steps );
	$min = (int) get_post_meta( $product_id, '_ibr_len_min', true );
	$max = (int) get_post_meta( $product_id, '_ibr_len_max', true );
	return array(
		'standard'  => $standard,
		'steps'     => $steps,
		'custom'    => 'yes' === get_post_meta( $product_id, '_ibr_len_custom', true ),
		'min'       => $min > 0 ? $min : 50,
		'max'       => $max > 0 ? $max : 1000,
		'surcharge' => (float) get_post_meta( $product_id, '_ibr_len_surcharge', true ),
		'step_cm'   => max( 1, (int) get_post_meta( $product_id, '_ibr_len_step_cm', true ) ?: 25 ),
	);
}

/**
 * Aufpreis je Schritt für die gewählte Variante: eigener Wert der Variante, sonst der des Produkts.
 */
function ibr_len_rate( int $variation_id, array $settings ): float {
	if ( $variation_id ) {
		$own = get_post_meta( $variation_id, '_ibr_len_surcharge', true );
		if ( '' !== $own && null !== $own ) {
			return (float) $own;
		}
	}
	return (float) $settings['surcharge'];
}

/**
 * Aufpreis für eine Länge: je angefangene Schrittweite über der Standardlänge.
 */
function ibr_len_surcharge( int $cm, array $settings, ?float $rate = null ): float {
	$rate = $rate ?? $settings['surcharge'];
	if ( $cm <= $settings['standard'] || $rate <= 0 ) {
		return 0.0;
	}
	return ceil( ( $cm - $settings['standard'] ) / $settings['step_cm'] ) * $rate;
}

/**
 * „225“ → „2,25 m“
 */
function ibr_len_format( int $cm ): string {
	return number_format( $cm / 100, 2, ',', '' ) . ' m';
}

/* ---------------------------------------------------------------------------
 * Reiter „Länge“ im Produkt
 * ------------------------------------------------------------------------- */

add_filter(
	'woocommerce_product_data_tabs',
	static function ( array $tabs ): array {
		$tabs['ibr_laenge'] = array(
			'label'    => 'Länge',
			'target'   => 'ibr_laenge_panel',
			'priority' => 66,
		);
		return $tabs;
	}
);

add_action(
	'woocommerce_product_data_panels',
	static function (): void {
		echo '<div id="ibr_laenge_panel" class="panel woocommerce_options_panel"><div class="options_group">';
		woocommerce_wp_text_input(
			array(
				'id'                => '_ibr_len_standard',
				'label'             => 'Standardlänge (cm)',
				'type'              => 'number',
				'placeholder'       => 'leer = keine Längenwahl',
				'custom_attributes' => array( 'min' => 1 ),
				'desc_tip'          => true,
				'description'       => 'Die Länge, die normalerweise geliefert wird, z. B. 200. Leer lassen, wenn das Produkt keine Längenwahl hat.',
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'          => '_ibr_len_steps',
				'label'       => 'Weitere Längen (cm)',
				'placeholder' => 'z. B. 225, 250',
				'desc_tip'    => true,
				'description' => 'Längen zum Antippen, durch Komma getrennt.',
			)
		);
		woocommerce_wp_checkbox(
			array(
				'id'          => '_ibr_len_custom',
				'label'       => 'Wunschlänge erlauben',
				'description' => 'Kund*innen können eine eigene Länge in cm eintragen.',
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'                => '_ibr_len_min',
				'label'             => 'Wunschlänge mindestens (cm)',
				'type'              => 'number',
				'placeholder'       => '50',
				'custom_attributes' => array( 'min' => 1 ),
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'                => '_ibr_len_max',
				'label'             => 'Wunschlänge höchstens (cm)',
				'type'              => 'number',
				'placeholder'       => '1000',
				'custom_attributes' => array( 'min' => 1 ),
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'          => '_ibr_len_surcharge',
				'label'       => 'Aufpreis je Schritt (€)',
				'data_type'   => 'price',
				'placeholder' => '0,00',
				'desc_tip'    => true,
				'description' => 'Wird für jede angefangene Schrittweite über der Standardlänge berechnet. 0 = kein Aufpreis.',
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'                => '_ibr_len_step_cm',
				'label'             => 'Schrittweite (cm)',
				'type'              => 'number',
				'placeholder'       => '25',
				'custom_attributes' => array( 'min' => 1 ),
			)
		);
		echo '</div></div>';
	}
);

add_action(
	'woocommerce_admin_process_product_object',
	static function ( WC_Product $product ): void {
		// Die Nonce prüft WooCommerce beim Speichern des Produkts.
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$product->update_meta_data( '_ibr_len_standard', absint( $_POST['_ibr_len_standard'] ?? 0 ) ?: '' );
		$steps = array_filter( array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( $_POST['_ibr_len_steps'] ?? '' ) ) ) ) );
		$product->update_meta_data( '_ibr_len_steps', implode( ', ', $steps ) );
		$product->update_meta_data( '_ibr_len_custom', isset( $_POST['_ibr_len_custom'] ) ? 'yes' : 'no' );
		$product->update_meta_data( '_ibr_len_min', absint( $_POST['_ibr_len_min'] ?? 0 ) ?: '' );
		$product->update_meta_data( '_ibr_len_max', absint( $_POST['_ibr_len_max'] ?? 0 ) ?: '' );
		$product->update_meta_data( '_ibr_len_surcharge', wc_format_decimal( wp_unslash( $_POST['_ibr_len_surcharge'] ?? '' ) ) );
		$product->update_meta_data( '_ibr_len_step_cm', absint( $_POST['_ibr_len_step_cm'] ?? 0 ) ?: '' );
		// phpcs:enable
	}
);

/* ---------------------------------------------------------------------------
 * Auswahl auf der Produktseite
 * ------------------------------------------------------------------------- */

add_action(
	'wp_enqueue_scripts',
	static function (): void {
		if ( ! is_product() ) {
			return;
		}
		wp_enqueue_style( 'ibr-laengenwahl', plugins_url( 'assets/laengenwahl.css', IBR_PO_FILE ), array(), IBR_PO_VERSION );
		wp_enqueue_script( 'ibr-laengenwahl', plugins_url( 'assets/laengenwahl.js', IBR_PO_FILE ), array( 'jquery' ), IBR_PO_VERSION, true );
	}
);

add_action(
	'woocommerce_before_add_to_cart_button',
	static function (): void {
		global $product;
		if ( ! $product instanceof WC_Product ) {
			return;
		}
		$s = ibr_len_settings( $product->get_id() );
		if ( ! $s ) {
			return;
		}

		$option = static function ( string $value, string $label, float $extra, bool $checked ): void {
			printf(
				'<label class="ibr-len__option"><input type="radio" name="ibr_len" value="%1$s"%4$s><span>%2$s%3$s</span></label>',
				esc_attr( $value ),
				esc_html( $label ),
				is_numeric( $value ) ? sprintf( '<small class="ibr-len__extra" data-cm="%d"%s> + %s</small>', (int) $value, $extra > 0 ? '' : ' hidden', esc_html( wp_strip_all_tags( wc_price( $extra ) ) ) ) : '',
				$checked ? ' checked' : ''
			);
		};

		printf(
			'<fieldset class="ibr-len" data-standard="%d" data-step="%d" data-rate="%s"><legend class="ibr-len__title">Länge</legend><div class="ibr-len__options">',
			(int) $s['standard'],
			(int) $s['step_cm'],
			esc_attr( (string) $s['surcharge'] )
		);
		$option( (string) $s['standard'], ibr_len_format( $s['standard'] ) . ' (Standard)', 0, true );
		foreach ( $s['steps'] as $cm ) {
			$option( (string) $cm, ibr_len_format( $cm ), ibr_len_surcharge( $cm, $s ), false );
		}
		if ( $s['custom'] ) {
			$option( 'custom', 'Wunschlänge', 0, false );
		}
		echo '</div>';

		if ( $s['custom'] ) {
			$hint = sprintf( 'Zwischen %s und %s.', ibr_len_format( $s['min'] ), ibr_len_format( $s['max'] ) );
			$hint .= sprintf(
				' <span class="ibr-len__rate-text"%4$s>Über %1$s je angefangene %2$d cm + <span class="ibr-len__rate">%3$s</span>.</span>',
				esc_html( ibr_len_format( $s['standard'] ) ),
				(int) $s['step_cm'],
				esc_html( wp_strip_all_tags( wc_price( $s['surcharge'] ) ) ),
				$s['surcharge'] > 0 ? '' : ' hidden'
			);
			printf(
				'<div class="ibr-len__custom" hidden><label for="ibr_len_custom">Deine Wunschlänge in cm</label><input type="number" id="ibr_len_custom" name="ibr_len_custom" min="%1$d" max="%2$d" step="1" inputmode="numeric" placeholder="z. B. %3$d" disabled><p class="ibr-len__hint">%4$s</p></div>',
				(int) $s['min'],
				(int) $s['max'],
				(int) $s['standard'] + 15,
				wp_kses( $hint, array( 'span' => array( 'class' => true, 'hidden' => true ) ) )
			);
		}
		echo '</fieldset>';
	},
	5
);

/* ---------------------------------------------------------------------------
 * Warenkorb, Preis und Bestellung
 * ------------------------------------------------------------------------- */

/**
 * Gewählte Länge aus dem Formular lesen. Ohne Angabe (z. B. aus einer Übersicht) gilt die Standardlänge.
 *
 * @return int|WP_Error Länge in cm
 */
function ibr_len_from_request( array $s ) {
	// phpcs:disable WordPress.Security.NonceVerification.Missing
	$choice = sanitize_text_field( wp_unslash( $_POST['ibr_len'] ?? '' ) );
	if ( '' === $choice ) {
		return $s['standard'];
	}
	if ( 'custom' === $choice && $s['custom'] ) {
		$raw = trim( (string) wp_unslash( $_POST['ibr_len_custom'] ?? '' ) );
		// phpcs:enable
		if ( '' === $raw || ! preg_match( '/^\d+$/', $raw ) ) {
			return new WP_Error( 'ibr_len', 'Bitte trage deine Wunschlänge in ganzen Zentimetern ein.' );
		}
		$cm = (int) $raw;
		if ( $cm < $s['min'] || $cm > $s['max'] ) {
			return new WP_Error( 'ibr_len', sprintf( 'Die Wunschlänge muss zwischen %s und %s liegen.', ibr_len_format( $s['min'] ), ibr_len_format( $s['max'] ) ) );
		}
		return $cm;
	}
	$cm = (int) $choice;
	if ( $cm === $s['standard'] || in_array( $cm, $s['steps'], true ) ) {
		return $cm;
	}
	return new WP_Error( 'ibr_len', 'Bitte wähle eine Länge.' );
}

add_filter(
	'woocommerce_add_to_cart_validation',
	static function ( bool $valid, int $product_id ): bool {
		$s = ibr_len_settings( $product_id );
		if ( ! $s ) {
			return $valid;
		}
		$cm = ibr_len_from_request( $s );
		if ( is_wp_error( $cm ) ) {
			wc_add_notice( $cm->get_error_message(), 'error' );
			return false;
		}
		return $valid;
	},
	10,
	2
);

add_filter(
	'woocommerce_add_cart_item_data',
	static function ( array $data, int $product_id, int $variation_id = 0 ): array {
		$s = ibr_len_settings( $product_id );
		if ( ! $s ) {
			return $data;
		}
		$cm = ibr_len_from_request( $s );
		if ( is_wp_error( $cm ) ) {
			return $data;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$custom          = 'custom' === sanitize_text_field( wp_unslash( $_POST['ibr_len'] ?? '' ) );
		$data['ibr_len'] = array(
			'cm'        => $cm,
			'custom'    => $custom,
			'surcharge' => ibr_len_surcharge( $cm, $s, ibr_len_rate( $variation_id, $s ) ),
		);
		return $data;
	},
	10,
	3
);

// Aufpreis auf den Artikelpreis rechnen (klassischer und Block-Warenkorb).
add_action(
	'woocommerce_before_calculate_totals',
	static function ( WC_Cart $cart ): void {
		foreach ( $cart->get_cart() as $item ) {
			$extra = (float) ( $item['ibr_len']['surcharge'] ?? 0 );
			if ( $extra <= 0 ) {
				continue;
			}
			$fresh = wc_get_product( $item['data']->get_id() );
			if ( $fresh ) {
				$item['data']->set_price( (float) $fresh->get_price() + $extra );
			}
		}
	},
	20
);

add_filter(
	'woocommerce_get_item_data',
	static function ( array $item_data, array $cart_item ): array {
		if ( empty( $cart_item['ibr_len'] ) ) {
			return $item_data;
		}
		$len         = $cart_item['ibr_len'];
		$item_data[] = array(
			'key'   => 'Länge',
			'value' => ibr_len_format( (int) $len['cm'] ) . ( $len['custom'] ? ' (Wunschlänge)' : '' ),
		);
		return $item_data;
	},
	10,
	2
);

add_action(
	'woocommerce_checkout_create_order_line_item',
	static function ( WC_Order_Item_Product $item, string $key, array $values ): void {
		if ( empty( $values['ibr_len'] ) ) {
			return;
		}
		$len = $values['ibr_len'];
		$item->add_meta_data( 'Länge', ibr_len_format( (int) $len['cm'] ) . ( $len['custom'] ? ' (Wunschlänge)' : '' ) );
		if ( $len['surcharge'] > 0 ) {
			$item->add_meta_data( 'Aufpreis Länge', wp_strip_all_tags( wc_price( $len['surcharge'] ) ) );
		}
	},
	10,
	3
);

/* ---------------------------------------------------------------------------
 * Eigener Aufpreis pro Variante (z. B. 8 mm günstiger als 10 mm)
 * ------------------------------------------------------------------------- */

add_action(
	'woocommerce_product_after_variable_attributes',
	static function ( int $loop, array $variation_data, WP_Post $variation ): void {
		woocommerce_wp_text_input(
			array(
				'id'            => "ibr_len_surcharge_{$loop}",
				'name'          => "ibr_len_surcharge[{$loop}]",
				'label'         => 'Aufpreis Länge je Schritt (€)',
				'data_type'     => 'price',
				'placeholder'   => 'wie beim Produkt',
				'value'         => wc_format_localized_price( (string) get_post_meta( $variation->ID, '_ibr_len_surcharge', true ) ),
				'wrapper_class' => 'form-row form-row-last',
			)
		);
	},
	11,
	3
);

add_action(
	'woocommerce_save_product_variation',
	static function ( int $variation_id, int $loop ): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$raw = trim( (string) wp_unslash( $_POST['ibr_len_surcharge'][ $loop ] ?? '' ) );
		update_post_meta( $variation_id, '_ibr_len_surcharge', '' === $raw ? '' : wc_format_decimal( $raw ) );
	},
	10,
	2
);

add_filter(
	'woocommerce_available_variation',
	static function ( array $data, WC_Product $product, WC_Product_Variation $variation ): array {
		$s = ibr_len_settings( $product->get_id() );
		if ( $s ) {
			$data['ibr_len_rate'] = ibr_len_rate( $variation->get_id(), $s );
		}
		return $data;
	},
	10,
	3
);
