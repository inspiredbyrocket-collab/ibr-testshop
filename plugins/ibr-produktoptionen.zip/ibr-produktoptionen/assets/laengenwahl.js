/* Längenwahl: Feld für die Wunschlänge nur bei Auswahl „Wunschlänge“ zeigen und verlangen. */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		var box = document.querySelector( '.ibr-len' );
		if ( ! box ) {
			return;
		}
		var custom = box.querySelector( '.ibr-len__custom' );
		var input = custom ? custom.querySelector( 'input' ) : null;

		box.addEventListener( 'change', function ( event ) {
			if ( event.target.name !== 'ibr_len' || ! custom ) {
				return;
			}
			var on = event.target.value === 'custom';
			custom.hidden = ! on;
			input.disabled = ! on;
			input.required = on;
			if ( on ) {
				input.focus();
			}
		} );
	} );
} )();
