/*
 * Längenwahl: Feld für die Wunschlänge nur bei „Wunschlänge“ zeigen und verlangen;
 * Aufpreise neu berechnen, wenn eine Variante mit eigenem Aufpreis gewählt wird.
 */
( function () {
	'use strict';

	var euro = new Intl.NumberFormat( 'de-DE', { style: 'currency', currency: 'EUR' } );

	document.addEventListener( 'DOMContentLoaded', function () {
		var box = document.querySelector( '.ibr-len' );
		if ( ! box ) {
			return;
		}
		var custom = box.querySelector( '.ibr-len__custom' );
		var input = custom ? custom.querySelector( 'input' ) : null;
		var standard = Number( box.getAttribute( 'data-standard' ) );
		var step = Number( box.getAttribute( 'data-step' ) ) || 25;
		var defaultRate = Number( box.getAttribute( 'data-rate' ) ) || 0;
		var rateAttr = box.getAttribute( 'data-rate-attr' ) || '';
		var rateMap = {};
		try {
			rateMap = JSON.parse( box.getAttribute( 'data-rate-map' ) || '{}' );
		} catch ( e ) {}
		var form = box.closest( 'form' );
		var currentRate = defaultRate;

		// Aktuellen Längen-Aufpreis melden, damit der Preis oben gleich mitrechnet.
		function emitExtra() {
			var checked = box.querySelector( 'input[name="ibr_len"]:checked' );
			var cm = standard;
			if ( checked && checked.value === 'custom' ) {
				cm = Number( input && input.value ) || standard;
			} else if ( checked ) {
				cm = Number( checked.value ) || standard;
			}
			var extra = cm > standard ? Math.ceil( ( cm - standard ) / step ) * currentRate : 0;
			box.setAttribute( 'data-extra', String( extra ) );
			if ( window.jQuery && form ) {
				window.jQuery( form ).trigger( 'ibr_len_extra', [ extra ] );
			}
		}
		box.addEventListener( 'input', emitExtra );

		// Aufpreis schon aus der bestimmenden Eigenschaft ablesen (z. B. Stärke).
		function rateFromForm() {
			var field = rateAttr && form ? form.querySelector( '[name="' + rateAttr + '"]' ) : null;
			var value = field ? field.value : '';
			return value && typeof rateMap[ value ] !== 'undefined' ? Number( rateMap[ value ] ) : defaultRate;
		}

		box.addEventListener( 'change', function ( event ) {
			if ( event.target.name !== 'ibr_len' || ! custom ) {
				return;
			}
			var on = event.target.value === 'custom';
			custom.hidden = ! on;
			input.disabled = ! on;
			input.required = on;
			if ( on ) {
				input.focus();
			}
		} );
		box.addEventListener( 'change', emitExtra );

		function showRate( rate ) {
			currentRate = rate;
			box.querySelectorAll( '.ibr-len__extra' ).forEach( function ( el ) {
				var cm = Number( el.getAttribute( 'data-cm' ) );
				var extra = cm > standard ? Math.ceil( ( cm - standard ) / step ) * rate : 0;
				el.textContent = ' + ' + euro.format( extra );
				el.hidden = extra <= 0;
			} );
			var rateEl = box.querySelector( '.ibr-len__rate' );
			if ( rateEl ) {
				rateEl.textContent = euro.format( rate );
				rateEl.closest( '.ibr-len__rate-text' ).hidden = rate <= 0;
			}
			emitExtra();
		}

		// Variantenwechsel kommt als jQuery-Ereignis von WooCommerce.
		if ( window.jQuery ) {
			window.jQuery( 'form.variations_form' )
				.on( 'found_variation', function ( event, variation ) {
					if ( typeof variation.ibr_len_rate !== 'undefined' ) {
						showRate( Number( variation.ibr_len_rate ) );
					}
				} )
				.on( 'reset_data', function () {
					showRate( rateFromForm() );
				} )
				.on( 'change', 'select', function () {
					showRate( rateFromForm() );
				} );
			showRate( rateFromForm() );
		}
	} );
} )();
