/*
 * Farbwahl: zeigt die passende Palette zur gewählten Variante (z. B. 8 mm oder 10 mm),
 * passt die Anzahl der Farben an und zeigt den Namen der gewählten Farbe.
 */
( function ( $ ) {
	'use strict';

	$( function () {
		var $box = $( '.ibr-fw' );
		if ( ! $box.length ) {
			return;
		}

		var defaults = {
			palette: Number( $box.data( 'default-palette' ) ) || 0,
			slots: Number( $box.data( 'slots' ) ) || 1,
		};
		var state = { palette: defaults.palette, slots: defaults.slots };
		var slotAttr = $box.data( 'slot-attr' );

		function render() {
			$box.find( '.ibr-fw__wait' ).prop( 'hidden', !! state.palette );

			$box.find( '.ibr-fw__slot' ).each( function () {
				var slotActive = state.palette && Number( this.getAttribute( 'data-slot' ) ) < state.slots;
				this.hidden = ! slotActive;

				$( this ).find( '.ibr-fw__swatches' ).each( function () {
					var groupActive = slotActive && Number( this.getAttribute( 'data-palette' ) ) === state.palette;
					this.hidden = Number( this.getAttribute( 'data-palette' ) ) !== state.palette;
					$( this ).find( 'input' ).each( function () {
						this.disabled = ! groupActive;
						if ( ! groupActive ) {
							this.checked = false;
						}
					} );
				} );

				var $checked = $( this ).find( 'input:checked' );
				$( this ).find( '.ibr-fw__chosen' ).text(
					$checked.length ? $checked.closest( '.ibr-fw__swatch' ).attr( 'title' ) : 'bitte wählen'
				);
			} );
		}

		$box.on( 'change', 'input[type=radio]', function () {
			var name = $( this ).closest( '.ibr-fw__swatch' ).attr( 'title' );
			$( this ).closest( '.ibr-fw__slot' ).find( '.ibr-fw__chosen' ).text( name );
		} );

		$( 'form.variations_form' )
			.on( 'found_variation', function ( event, variation ) {
				if ( variation.ibr_fw_palette ) {
					state.palette = Number( variation.ibr_fw_palette );
				}
				if ( slotAttr ) {
					var value = ( variation.attributes || {} )[ 'attribute_' + slotAttr ] || '';
					var match = String( value ).match( /\d+/ );
					state.slots = match ? Math.min( 8, Number( match[ 0 ] ) ) : defaults.slots;
				}
				render();
			} )
			.on( 'reset_data', function () {
				state.palette = defaults.palette;
				state.slots = defaults.slots;
				render();
			} );
	} );
} )( jQuery );
