/*
 * Auswahl-Knöpfe: setzen die unsichtbare WooCommerce-Auswahlliste, zeigen die Wahl an,
 * grauen nicht lieferbare Werte aus und zeigen Aufpreise („+ 4,00 €“).
 */
( function ( $ ) {
	'use strict';

	function formatPrice( value, f ) {
		var fixed = Math.abs( value ).toFixed( f.decimals );
		var parts = fixed.split( '.' );
		parts[ 0 ] = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, f.thousand );
		return parts.join( f.decimal ) + ' ' + f.symbol;
	}

	$( function () {
		$( 'form.variations_form' ).each( function () {
			var $form = $( this );
			var $sels = $form.find( '.ibr-sel' );
			if ( ! $sels.length ) {
				return;
			}

			var data = {};
			try {
				data = JSON.parse( $form.find( '.ibr-sel-data' ).first().text() || '{}' );
			} catch ( e ) {
				data = {};
			}
			var format = data.format || { decimals: 2, decimal: ',', thousand: '.', symbol: '€' };

			function selectFor( $sel ) {
				return $form.find( 'select[name="' + $sel.data( 'attr' ) + '"]' );
			}

			// Ist der Wert in der WooCommerce-Liste gerade wählbar?
			function available( $select, value ) {
				var ok = false;
				$select.find( 'option' ).each( function () {
					if ( this.value === value ) {
						ok = ! this.disabled;
					}
				} );
				return ok;
			}

			// Kleinster Preis je Wert, passend zur gewählten Hauptauswahl (z. B. Stärke).
			function pricesFor( attr ) {
				var all = data.prices || {};
				var main = data.main ? String( $form.find( 'select[name="' + data.main + '"]' ).val() || '' ) : '';
				if ( main && all[ main ] ) {
					return all[ main ][ attr ] || {};
				}
				var merged = {};
				Object.keys( all ).forEach( function ( key ) {
					var list = all[ key ][ attr ] || {};
					Object.keys( list ).forEach( function ( value ) {
						merged[ value ] = value in merged ? Math.min( merged[ value ], list[ value ] ) : list[ value ];
					} );
				} );
				return merged;
			}

			function render() {
				$sels.each( function () {
					var $sel = $( this );
					var $select = selectFor( $sel );
					var current = String( $select.val() || '' );

					$sel.find( '.ibr-sel__card, .ibr-sel__field' ).each( function () {
						var value = String( this.getAttribute( 'data-value' ) );
						this.classList.toggle( 'is-unavailable', ! available( $select, value ) );
						this.setAttribute( 'aria-pressed', value === current ? 'true' : 'false' );
					} );

					$sel.find( '.ibr-sel__switch' ).each( function () {
						var on = String( this.getAttribute( 'data-on' ) );
						var off = String( this.getAttribute( 'data-off' ) );
						this.setAttribute( 'aria-checked', current === on ? 'true' : 'false' );
						this.classList.toggle( 'is-unavailable', ! available( $select, on ) );
					} );

					// Aufpreise gegenüber der günstigsten Möglichkeit dieser Eigenschaft
					if ( ! $sel.data( 'main' ) ) {
						var prices = pricesFor( $sel.data( 'attr' ) );
						var values = Object.keys( prices ).map( function ( key ) {
							return prices[ key ];
						} );
						var min = values.length ? Math.min.apply( null, values ) : 0;
						$sel.find( '.ibr-sel__diff' ).each( function () {
							var value = String( this.getAttribute( 'data-value' ) );
							var diff = value in prices ? prices[ value ] - min : 0;
							this.textContent = diff > 0.004 ? '+ ' + formatPrice( diff, format ) : '';
						} );
					}
				} );
			}

			function choose( $sel, value ) {
				var $select = selectFor( $sel );
				// Passt der Wert nicht zur bisherigen Wahl, die anderen Eigenschaften zurücksetzen.
				if ( ! available( $select, value ) ) {
					$form.find( '.variations select' ).not( $select ).val( '' );
					$select.trigger( 'change' );
					$select = selectFor( $sel );
				}
				if ( String( $select.val() || '' ) !== value ) {
					$select.val( value ).trigger( 'change' );
				}
				render();
			}

			$sels.on( 'click', '.ibr-sel__card, .ibr-sel__field', function () {
				choose( $( this ).closest( '.ibr-sel' ), String( this.getAttribute( 'data-value' ) ) );
			} );

			$sels.on( 'click', '.ibr-sel__switch', function () {
				var checked = this.getAttribute( 'aria-checked' ) === 'true';
				choose(
					$( this ).closest( '.ibr-sel' ),
					String( this.getAttribute( checked ? 'data-off' : 'data-on' ) )
				);
			} );

			// Schalter starten auf „aus“, damit nichts ungewählt bleibt.
			$sels.find( '.ibr-sel__switch' ).each( function () {
				var $select = selectFor( $( this ).closest( '.ibr-sel' ) );
				var off = String( this.getAttribute( 'data-off' ) );
				if ( ! $select.val() && available( $select, off ) ) {
					$select.val( off ).trigger( 'change' );
				}
			} );

			/* ---------------------------------------------------------------
			 * Preis live anzeigen: oben beim Produkt und direkt über dem Knopf.
			 * Stehen Stärke und Beschläge fest, gibt es einen genauen Preis
			 * (Schalter wie Leo-Upgrade stehen von Anfang an auf „aus“),
			 * sonst „ab …“ aus den noch möglichen Varianten. Der Längen-Aufpreis
			 * wird jeweils dazugerechnet.
			 * ------------------------------------------------------------- */
			var variations = $form.data( 'product_variations' ) || [];
			var lenExtra = Number( $form.find( '.ibr-len' ).attr( 'data-extra' ) ) || 0;
			var found = null;

			// Preis oben beim Produkt. WooCommerce ersetzt ihn bei Variantenwahl selbst,
			// daher jedes Mal neu suchen und danach wieder unseren Preis einsetzen.
			function findTop() {
				return $( '.wp-block-woocommerce-product-price, .summary .price' ).filter( function () {
					return ! $( this ).closest( '.wp-block-woocommerce-product-template, .wc-block-product, .related, .upsells, .products' ).length;
				} ).first();
			}
			var $top = findTop();
			var topOriginal = $top.html();
			var topText = null;
			var observer = window.MutationObserver ? new window.MutationObserver( function () {
				writeTop();
			} ) : null;

			function writeTop() {
				if ( $top.length && ! document.body.contains( $top[ 0 ] ) ) {
					$top = findTop();
					if ( observer && $top.length ) {
						observer.observe( $top[ 0 ], { childList: true, subtree: true, characterData: true } );
					}
				}
				if ( ! $top.length ) {
					return;
				}
				if ( null === topText ) {
					if ( $top.find( '.ibr-live-price' ).length ) {
						$top.html( topOriginal );
					}
					return;
				}
				var $live = $top.find( '.ibr-live-price' );
				if ( $live.length === 1 && $live.text() === topText ) {
					return;
				}
				var $inner = $top.find( '.wc-block-components-product-price' ).first();
				( $inner.length ? $inner : $top ).html( '<span class="ibr-live-price"></span>' ).find( '.ibr-live-price' ).text( topText );
			}

			if ( observer && $top.length ) {
				observer.observe( $top[ 0 ], { childList: true, subtree: true, characterData: true } );
			}

			var $total = $( '<p class="ibr-sel-total" aria-live="polite"></p>' );
			// Direkt über Menge und Knopf, also nach Länge und Farben.
			var $place = $form.find( '.woocommerce-variation-add-to-cart .quantity' ).first();
			if ( ! $place.length ) {
				$place = $form.find( '.single_variation_wrap' ).first();
			}
			if ( $place.length ) {
				$place.before( $total );
			}

			// Lagerangabe („3 vorrätig“) unten bei Menge und Knopf statt oben unter der Auswahl.
			var $stock = $( '<p class="ibr-sel-stock" aria-live="polite" hidden></p>' );
			$total.after( $stock );
			$form
				.on( 'found_variation', function ( event, variation ) {
					var text = $( '<div>' ).html( variation.availability_html || '' ).text().trim();
					$stock.text( text ).prop( 'hidden', ! text )
						.toggleClass( 'is-out', variation.is_in_stock === false );
				} )
				.on( 'reset_data hide_variation', function () {
					$stock.text( '' ).prop( 'hidden', true );
				} );

			function chosenAttrs() {
				var chosen = {};
				$form.find( '.variations select' ).each( function () {
					chosen[ this.name ] = String( $( this ).val() || '' );
				} );
				return chosen;
			}

			// Namen der noch offenen Eigenschaften, z. B. „Beschläge“.
			function missing() {
				var names = [];
				$form.find( '.variations tr' ).each( function () {
					var $select = $( this ).find( 'select' );
					if ( $select.length && ! $select.val() ) {
						names.push( $.trim( $( this ).find( 'th.label label' ).first().text() ) );
					}
				} );
				return names;
			}

			function priceState() {
				if ( found ) {
					return { exact: true, price: Number( found.display_price ) + lenExtra };
				}
				var chosen = chosenAttrs();
				var complete = ! missing().length;
				var min = null;
				( Array.isArray( variations ) ? variations : [] ).forEach( function ( v ) {
					if ( ! v.is_purchasable || ! v.is_in_stock ) {
						return;
					}
					var fits = Object.keys( chosen ).every( function ( name ) {
						var want = chosen[ name ];
						var has = ( v.attributes || {} )[ name ];
						return ! want || ! has || want === has;
					} );
					if ( fits ) {
						min = null === min ? Number( v.display_price ) : Math.min( min, Number( v.display_price ) );
					}
				} );
				return null === min ? null : { exact: complete, price: min + lenExtra };
			}

			function renderPrice() {
				var state = priceState();
				if ( ! state ) {
					topText = null;
					writeTop();
					$total.text( '' ).prop( 'hidden', true );
					return;
				}
				var text = ( state.exact ? '' : 'ab ' ) + formatPrice( state.price, format );
				topText = text;
				writeTop();
				$total.prop( 'hidden', false ).html(
					( state.exact ? 'Dein Preis: ' : 'Preis ' ) + '<strong>' + text + '</strong>' +
					( state.exact ? '' : ' <span>· wähle noch ' + $( '<i>' ).text( missing().join( ' und ' ) ).html() + '</span>' )
				);
			}

			$form
				.on( 'found_variation', function ( event, variation ) {
					found = variation;
					window.setTimeout( renderPrice, 0 );
				} )
				.on( 'reset_data hide_variation', function () {
					found = null;
					window.setTimeout( renderPrice, 0 );
				} )
				.on( 'ibr_len_extra', function ( event, extra ) {
					lenExtra = Number( extra ) || 0;
					renderPrice();
				} )
				.on( 'change', '.variations select', function () {
					window.setTimeout( renderPrice, 0 );
				} );

			$form.on( 'woocommerce_update_variation_values reset_data found_variation change', function () {
				// WooCommerce baut die Listen erst nach dem Ereignis neu auf.
				window.setTimeout( render, 0 );
			} );

			render();
			renderPrice();
		} );
	} );
} )( jQuery );
