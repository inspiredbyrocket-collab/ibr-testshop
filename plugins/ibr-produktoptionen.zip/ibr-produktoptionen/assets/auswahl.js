/*
 * Auswahl-Knöpfe: setzen die unsichtbare WooCommerce-Auswahlliste, zeigen die Wahl an,
 * grauen nicht lieferbare Werte aus und zeigen Aufpreise („+ 4,00 €“).
 */
( function ( $ ) {
	'use strict';

	function formatPrice( value, f ) {
		var fixed = Math.abs( value ).toFixed( f.decimals );
		var parts = fixed.split( '.' );
		parts[ 0 ] = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, f.thousand );
		return parts.join( f.decimal ) + ' ' + f.symbol;
	}

	$( function () {
		$( 'form.variations_form' ).each( function () {
			var $form = $( this );
			var $sels = $form.find( '.ibr-sel' );
			if ( ! $sels.length ) {
				return;
			}

			var data = {};
			try {
				data = JSON.parse( $form.find( '.ibr-sel-data' ).first().text() || '{}' );
			} catch ( e ) {
				data = {};
			}
			var format = data.format || { decimals: 2, decimal: ',', thousand: '.', symbol: '€' };

			function selectFor( $sel ) {
				return $form.find( 'select[name="' + $sel.data( 'attr' ) + '"]' );
			}

			// Ist der Wert in der WooCommerce-Liste gerade wählbar?
			function available( $select, value ) {
				var ok = false;
				$select.find( 'option' ).each( function () {
					if ( this.value === value ) {
						ok = ! this.disabled;
					}
				} );
				return ok;
			}

			// Kleinster Preis je Wert, passend zur gewählten Hauptauswahl (z. B. Stärke).
			function pricesFor( attr ) {
				var all = data.prices || {};
				var main = data.main ? String( $form.find( 'select[name="' + data.main + '"]' ).val() || '' ) : '';
				if ( main && all[ main ] ) {
					return all[ main ][ attr ] || {};
				}
				var merged = {};
				Object.keys( all ).forEach( function ( key ) {
					var list = all[ key ][ attr ] || {};
					Object.keys( list ).forEach( function ( value ) {
						merged[ value ] = value in merged ? Math.min( merged[ value ], list[ value ] ) : list[ value ];
					} );
				} );
				return merged;
			}

			function render() {
				$sels.each( function () {
					var $sel = $( this );
					var $select = selectFor( $sel );
					var current = String( $select.val() || '' );

					$sel.find( '.ibr-sel__card, .ibr-sel__field' ).each( function () {
						var value = String( this.getAttribute( 'data-value' ) );
						this.classList.toggle( 'is-unavailable', ! available( $select, value ) );
						this.setAttribute( 'aria-pressed', value === current ? 'true' : 'false' );
					} );

					$sel.find( '.ibr-sel__switch' ).each( function () {
						var on = String( this.getAttribute( 'data-on' ) );
						var off = String( this.getAttribute( 'data-off' ) );
						this.setAttribute( 'aria-checked', current === on ? 'true' : 'false' );
						this.classList.toggle( 'is-unavailable', ! available( $select, on ) );
					} );

					// Aufpreise gegenüber der günstigsten Möglichkeit dieser Eigenschaft
					if ( ! $sel.data( 'main' ) ) {
						var prices = pricesFor( $sel.data( 'attr' ) );
						var values = Object.keys( prices ).map( function ( key ) {
							return prices[ key ];
						} );
						var min = values.length ? Math.min.apply( null, values ) : 0;
						$sel.find( '.ibr-sel__diff' ).each( function () {
							var value = String( this.getAttribute( 'data-value' ) );
							var diff = value in prices ? prices[ value ] - min : 0;
							this.textContent = diff > 0.004 ? '+ ' + formatPrice( diff, format ) : '';
						} );
					}
				} );
			}

			function choose( $sel, value ) {
				var $select = selectFor( $sel );
				// Passt der Wert nicht zur bisherigen Wahl, die anderen Eigenschaften zurücksetzen.
				if ( ! available( $select, value ) ) {
					$form.find( '.variations select' ).not( $select ).val( '' );
					$select.trigger( 'change' );
					$select = selectFor( $sel );
				}
				if ( String( $select.val() || '' ) !== value ) {
					$select.val( value ).trigger( 'change' );
				}
				render();
			}

			$sels.on( 'click', '.ibr-sel__card, .ibr-sel__field', function () {
				choose( $( this ).closest( '.ibr-sel' ), String( this.getAttribute( 'data-value' ) ) );
			} );

			$sels.on( 'click', '.ibr-sel__switch', function () {
				var checked = this.getAttribute( 'aria-checked' ) === 'true';
				choose(
					$( this ).closest( '.ibr-sel' ),
					String( this.getAttribute( checked ? 'data-off' : 'data-on' ) )
				);
			} );

			// Schalter starten auf „aus“, damit nichts ungewählt bleibt.
			$sels.find( '.ibr-sel__switch' ).each( function () {
				var $select = selectFor( $( this ).closest( '.ibr-sel' ) );
				var off = String( this.getAttribute( 'data-off' ) );
				if ( ! $select.val() && available( $select, off ) ) {
					$select.val( off ).trigger( 'change' );
				}
			} );

			$form.on( 'woocommerce_update_variation_values reset_data found_variation change', function () {
				// WooCommerce baut die Listen erst nach dem Ereignis neu auf.
				window.setTimeout( render, 0 );
			} );

			render();
		} );
	} );
} )( jQuery );
