<?php
/**
 * Plugin Name: Inspired by Rocket – Produktoptionen
 * Description: Individuelle Wünsche am Produkt: Farbwahl mit Seil-Fotos (Produkte → Seilfarben) und Längenwahl mit Wunschlänge. Einstellungen pro Produkt im Reiter „Farbwahl“ bzw. „Länge“.
 * Version: 0.2.0
 * Requires PHP: 8.1
 * Requires Plugins: woocommerce
 * Author: Inspired by Rocket
 * Text Domain: ibr-produktoptionen
 *
 * @package ibr-produktoptionen
 */

defined( 'ABSPATH' ) || exit;

const IBR_PO_VERSION = '0.2.0';
const IBR_PO_FILE    = __FILE__;

require_once __DIR__ . '/includes/farbwahl.php';
require_once __DIR__ . '/includes/laengenwahl.php';
