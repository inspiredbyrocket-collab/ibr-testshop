/* Farbwahl: Namen der gewählten Farbe anzeigen und Anzahl der Farben an die Variante anpassen. */
( function ( $ ) {
	'use strict';

	$( function () {
		var $box = $( '.ibr-fw' );
		if ( ! $box.length ) {
			return;
		}

		$box.on( 'change', 'input[type=radio]', function () {
			var name = $( this ).closest( '.ibr-fw__swatch' ).attr( 'title' );
			$( this ).closest( '.ibr-fw__slot' ).find( '.ibr-fw__chosen' ).text( name );
		} );

		function setSlots( count ) {
			$box.find( '.ibr-fw__slot' ).each( function () {
				var active = Number( this.getAttribute( 'data-slot' ) ) < count;
				this.hidden = ! active;
				$( this ).find( 'input' ).prop( 'disabled', ! active );
			} );
		}

		var attr = $box.data( 'slot-attr' );
		if ( attr ) {
			$( 'form.variations_form' )
				.on( 'found_variation', function ( event, variation ) {
					var value = ( variation.attributes || {} )[ 'attribute_' + attr ] || '';
					var match = String( value ).match( /\d+/ );
					setSlots( match ? Math.min( 8, Number( match[ 0 ] ) ) : Number( $box.data( 'slots' ) ) );
				} )
				.on( 'reset_data', function () {
					setSlots( Number( $box.data( 'slots' ) ) );
				} );
		}
	} );
} )( jQuery );
